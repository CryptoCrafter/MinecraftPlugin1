package com.garrett.plugin1;

import org.bukkit.plugin.java.JavaPlugin;

public class SpigotPlugin1 extends JavaPlugin{
	
    // Fired when plugin is first enabled
    @Override
    public void onEnable() {
    }
    // Fired when plugin is disabled
    @Override
    public void onDisable() {

    }

}
